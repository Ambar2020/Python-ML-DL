from django import forms

class CreatePostForm(forms.Form):
	STATUS_CHOICES = (
		('D', 'Draft'),
		('P', 'Published')
	)
	title = forms.CharField(max_length = 100, required = True)
	description = forms.CharField(widget=forms.Textarea(), required = True)
	image = forms.CharField(widget=forms.Textarea())
	status = forms.ChoiceField(widget=forms.Select(), choices = STATUS_CHOICES)

	def clean_description(self):
		description = self.cleaned_data['description']
		num_of_words = len(description.split(' '))

		if num_of_words < 3:
			raise forms.ValidationError('Description too small!!')

		return description
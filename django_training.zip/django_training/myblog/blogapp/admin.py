from django.contrib import admin

from blogapp.models import Blog

# Register your models here.
admin.site.register(Blog)
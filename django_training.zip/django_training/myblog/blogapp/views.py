from django.shortcuts import render, redirect
from django.http import HttpResponse

from blogapp.models import Blog
from blogapp.forms import CreatePostForm

# Create your views here.
def index(request):
	blogs = Blog.objects.all()

	context = {
		'blogs': blogs
	}

	return render(request, 'index.html', context)

def about(request):
	return HttpResponse('About Us')

def tnc(request):
	return HttpResponse('Terms and Conditions')

def details(request, id):
	blog = Blog.objects.get(id=id)
	context = {
		'blog': blog
	}
	return render(request, 'details.html', context)

def search(request):
	if request.method == 'GET':
		query = request.GET['q']
		blogs = Blog.objects.filter(title__contains = query)
		return render(request, 'search.html', {'blogs':blogs})

def create_post(request):
	message = []
	if request.method == 'POST':
		form = CreatePostForm(request.POST)
		if form.is_valid():
			cd = form.cleaned_data
			print(cd)
			blog = Blog(
					title = cd['title'],
					description = cd['description'],
					image = cd['image'],
					status = cd['status']
				)
			blog.save()
			return redirect('/home/')
		else:
			message.append(form.errors)
	else:
		form = CreatePostForm()

	return render(request, 'create_post.html', {'form': form, 'messages': message})